/**
 * you can put a one sentence description of your tool here.
 *
 * (C) 2013
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author		Diffuse http://diffuse.io
 * @modified	03/02/2014
 * @version		##version##
 */

package com.reactag.exporter;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import processing.app.Base;
import processing.app.Editor;
import processing.app.Sketch;
import processing.app.SketchException;
import processing.app.tools.Tool;
import processing.core.PApplet;
import processing.mode.java.JavaEditor;
import processing.mode.java.JavaMode;
import processing.opengl.PGraphicsOpenGL;

import com.android.dx.command.dexer.Main.Arguments;

public class Exporter implements Tool {

	JavaEditor editor;
	JFrame frame;

	public String getMenuTitle() {
		return "Export to Reactag";
	}

	public void init(Editor editor) {
		this.editor = (JavaEditor) editor;
	}

	public void run() {
		export();

	}

	public void export() {
		final Sketch sketch = editor.getSketch();
		if (handleExportCheckModified()) {
			editor.statusNotice("Exporting...");
			try {
				File outDir = new File(sketch.getFolder().getAbsolutePath() + "/reactag/" + sketch.getName());
				outDir.mkdirs();
				
				// EXPORT SKETCH
				((JavaMode) editor.getMode()).handleExportApplication(sketch);

				// find jar file
				ArrayList<File> jarFiles = new ArrayList<File>();
				search(sketch.getFolder().getAbsolutePath(), jarFiles, new FilenameFilter() {
					@Override
					public boolean accept(File dir, String name) {
						// TODO Auto-generated method stub
						return name.equals(sketch.getName() + ".jar");
					}
				});

				if (jarFiles.size() == 0)
					throw new IOException("Can't locate '" + sketch.getName() + ".jar'");

				File jarFile = jarFiles.get(0);

				// load it
				URLClassLoader classLoader = new URLClassLoader(new URL[] { jarFile.toURI().toURL() }, this.getClass().getClassLoader());
				Class<?> clazz = classLoader.loadClass(sketch.getName());
				PApplet applet = (PApplet) clazz.newInstance();
				if(!(applet.g instanceof PGraphicsOpenGL))
					throw new SketchException("Sketch must use P2D or P3D.");

				// DEXIFY
				File dexJar = new File(outDir + "/data.jar");
				Arguments arguments = new Arguments();
				arguments.parse(new String[] { "--output=" + dexJar.getAbsolutePath(), jarFile.getAbsolutePath() });
				int result = com.android.dx.command.dexer.Main.run(arguments);
				if (result != 0)
					throw new IOException("Error creating dexed jar");

				editor.statusNotice("Done exporting.");

				Base.openFolder(outDir);
			} catch (IOException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (SketchException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				System.out.println(e.getMessage());
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				e.printStackTrace();
			} catch (InstantiationException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				e.printStackTrace();
			} catch (SecurityException e) {
				editor.statusNotice("Error during Photode export. See console for more information.");
				e.printStackTrace();
			} 
		}

	}

	protected boolean handleExportCheckModified() {
		if (editor.getSketch().isModified()) {
			Object[] options = { "OK", "Cancel" };
			int result = JOptionPane.showOptionDialog(editor, "Save changes before export?", "Save", JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

			if (result == JOptionPane.OK_OPTION) {
				editor.handleSave(true);

			} else {
				// why it's not CANCEL_OPTION is beyond me (at least on the mac)
				// but f-- it.. let's get this shite done..
				// } else if (result == JOptionPane.CANCEL_OPTION) {
				editor.statusNotice("Export canceled, changes must first be saved.");
				// toolbar.clear();
				return false;
			}
		}
		return true;
	}

	private void search(String path, ArrayList<File> foundFiles, FilenameFilter filter) {
		File root = new File(path);
		File[] list = root.listFiles();

		for (File f : list) {
			if (f.isDirectory()) {
				search(f.getAbsolutePath(), foundFiles, filter);
			} else {
				if (filter.accept(f.getAbsoluteFile(), f.getName()))
					foundFiles.add(f);
			}
		}
	}
}
